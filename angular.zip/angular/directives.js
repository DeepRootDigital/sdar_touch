'use strict';
var app = angular.module('app');

/*	****************

	Simple Square link Directive

	**************** */

app.directive('mySquare', function(){
	return {
		restrict: 'E',
		templateUrl:'partials/square.html'
,		link: function(scope, elm, attrs) {
			var color=attrs.color;
			var image=attrs.image;
			var type=attrs.type;
			var title=attrs.title;
			var link=attrs.link;

			$(elm).addClass('span-'+type);
			$(elm).find("span").eq(0).css({
				'background-color':color,
				'background-image':'url('+image+')',
				'background-repeat':'no-repeat',
				'background-position':'50% 50%'
			});
			$(elm).find("span").eq(1).html(title);
			$(elm).click(function(){
				window.location='#/'+link;
			})
		}
	}
});

/*	****************

	Weather Directive

	**************** */

app.directive('theWeather', function(){
	return {
		restrict: 'E',
		templateUrl:'partials/square.html'
,		link: function(scope, elm, attrs) {


			if (navigator.geolocation) {
		        navigator.geolocation.getCurrentPosition(showPosition);
		    } else { 
		        console.log("Geolocation is not supported by this browser.");
		    }

		    function showPosition(position) {		    	
				var weatherKEY='a4a9dafccc3f487b';
				var url = 'http://api.wunderground.com/api/'+weatherKEY+'/conditions/q/'+location+'.json';
			    var location = position.coords.latitude+','+position.coords.longitude;
			    $.ajax({ 
				url : 'http://api.wunderground.com/api/'+weatherKEY+'/geolookup/conditions/q/'+location+'.json', 
				dataType : "jsonp", 
				success : function(parsed_json) { 
					var location = parsed_json['location']['city']; 
					var temp_f = parsed_json['current_observation']['temp_f']; 
					var image = parsed_json['current_observation']['icon_url'];
					var feels_like = parsed_json['current_observation']['feelslike_f'];
					var city = parsed_json['current_observation']['display_location']['city'] + ',' + parsed_json['current_observation']['display_location']['state'];
					console.log(parsed_json['current_observation']);
					var title = city + ' Feels like:' + feels_like + ' Temp:' + temp_f + ' F'; 
					$(elm).find("span").eq(0).css({
						'background-image':'url('+image+')',
						'background-repeat':'no-repeat',
						'background-position':'50% 50%'
					});
					$(elm).find("span").eq(1).html(title);
				} 
				});
			}
			

			var color=attrs.color;
			var type=attrs.type;
			var title=attrs.title;
			var link=attrs.link;

			$(elm).addClass('span-'+type);
			$(elm).find("span").eq(0).css({
				'background-color':color
			});
			$(elm).click(function(){
				window.location='#/'+link;
			})
		}
	}
});

/*	****************

	Time Directive

	**************** */

app.directive('theTime', function(){
	return {
		restrict: 'E',
		templateUrl:'partials/square.html'
,		link: function(scope, elm, attrs) {
			var color=attrs.color;
			var image=attrs.image;
			var type=attrs.type;
			var title=attrs.title;

			$(elm).addClass('span-'+type);
			$(elm).find("span").eq(0).css({
				'background-color':color,
				'background-image':'url('+image+')',
				'background-repeat':'no-repeat',
				'background-position':'50% 50%'
			});
			$(elm).find("span").eq(1).html(title);
			$(elm).find("span").append("<div id='clock'></div>");			
			$(elm).find("#clock").clock();
			$(elm).click(function(){
				window.location='#/'+link;
			})
		}
	}
});

/*	****************

	Time Directive

	**************** */

app.directive('theNews', function(){
	return {
		restrict: 'E',
		templateUrl:'partials/square.html'
,		link: function(scope, elm, attrs) {
			$.ajax({
			  type: "POST",
			  url: "http://api.sdar.com/touchNews.php"
			})
			  .done(function( msg ) {
			    console.log( msg );
			  });
		}
	}
});